import { Search, Percent } from 'lucide-react';
import BottomNav from '@/components/BottomNav';

export default function MapsPage() {
  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Area Peta */}
      <div className="relative h-3/5 bg-gray-100 flex items-center justify-center">
        {/* Placeholder Peta */}
        <div className="absolute inset-0 bg-[#D1E8E2] flex items-center justify-center italic text-gray-400">
           [Map Interface Placeholder]
        </div>

        {/* Banner Diskon di Atas Peta */}
        <div className="absolute top-4 left-4 right-4 bg-green-900 text-white p-3 rounded-xl flex items-center justify-between text-xs font-bold z-10">
          <span>Save 15k with code 'NEWCOMER'</span>
          <Percent className="w-4 h-4" />
        </div>

        {/* Search Bar Map */}
        <div className="absolute bottom-12 left-4 right-4 z-10">
          <div className="relative">
            <Search className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
            <input className="w-full p-3.5 pl-12 rounded-full shadow-2xl border-none outline-none text-sm" placeholder="Search for destination" />
          </div>
        </div>
      </div>

      {/* Alamat Favorit Section (Bottom Sheet Style) */}
      <div className="flex-1 bg-white rounded-t-[40px] -mt-8 z-20 p-6 shadow-[0_-10px_30px_rgba(0,0,0,0.1)]">
        <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-8"></div>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-3">📄</div>
          <h4 className="font-extrabold text-sm text-gray-800">Save and address for a faster booking</h4>
          <p className="text-[11px] text-gray-400 mt-1">No favorite address added yet. Let's add it now!</p>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-4 no-scrollbar">
          {['Friend\'s house', 'Work', 'Binus', 'Your Residence'].map((loc) => (
            <button key={loc} className="whitespace-nowrap bg-gray-50 border border-gray-100 px-5 py-2.5 rounded-full text-[10px] font-bold text-gray-700 shadow-sm">
              {loc}
            </button>
          ))}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}