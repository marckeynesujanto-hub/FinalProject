"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FcGoogle } from "react-icons/fc";
import { signIn } from "next-auth/react";
import {
  FaUser,
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaApple,
  FaWindows,
} from "react-icons/fa";

export default function RegisterPage() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Konfigurasi Form Input
  const fields = [
    {
      name: "username",
      placeholder: "Username",
      icon: <FaUser className="text-black" />,
      type: "text",
    },
    {
      name: "email",
      placeholder: "Email",
      icon: <FaEnvelope className="text-black" />,
      type: "email",
    },
    {
      name: "password",
      placeholder: "Password",
      icon: <FaLock className="text-black" />,
      type: showPassword ? "text" : "password",
    },
  ];

  // Konfigurasi Social Providers
  const socialProviders = [
    { id: 'google', name: 'Google', icon: <FcGoogle className="text-xl" /> },
    { id: 'apple', name: 'Apple', icon: <FaApple className="text-xl text-black" /> },
    { id: 'microsoft', name: 'Microsoft', icon: <FaWindows className="text-xl text-black" /> },
  ];

  // State Penyimpanan Input
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // Proses Pengiriman Data (Manual Register)
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      // PERUBAHAN DI SINI: Menggunakan URL dari file .env.local
      const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

      const response = await fetch(`${apiUrl}/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Registrasi gagal");
      }

      alert("Registrasi Berhasil! Silakan login.");
      router.push("/login");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan koneksi");
    } finally {
      setIsLoading(false);
    }
  };

  // Fungsi Social Register dengan NextAuth
  const handleSocialRegister = (providerId: string) => {
    setIsLoading(true);
    // signIn akan mengarahkan user ke halaman login provider
    // Karena ini menggunakan OAuth, fungsi signIn berlaku untuk Login maupun Register
    signIn(providerId, { callbackUrl: "/dashboard" });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white text-black p-4 sm:p-8 font-serif">
      
      <form onSubmit={handleRegister} className="w-full max-w-[400px] flex flex-col items-center">
        
        <h1 className="text-3xl sm:text-4xl font-bold mb-6 tracking-wide uppercase text-center">
          REGISTER
        </h1>

        {/* Tampilan Error */}
        {error && (
          <div className="w-full mb-4 p-2 bg-red-100 border border-red-500 text-red-700 text-sm text-center">
            {error}
          </div>
        )}

        {/* INPUT FIELDS KOTAK */}
        <div className="w-full flex flex-col gap-0 mb-2">
          {fields.map((field) => (
            <div 
              key={field.name} 
              className="relative w-full border border-black flex items-center bg-white -mt-[1px]"
            >
              <div className="w-10 flex justify-center items-center py-2">
                {field.icon}
              </div>
              <input
                name={field.name}
                type={field.type}
                placeholder={field.placeholder}
                value={formData[field.name as keyof typeof formData]}
                onChange={handleChange}
                required
                className="w-full py-2 px-2 outline-none bg-transparent text-sm sm:text-base"
              />
              {field.name === "password" && (
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="px-3 py-2 focus:outline-none flex items-center justify-center"
                >
                  {showPassword ? <FaEye /> : <FaEyeSlash />}
                </button>
              )}
            </div>
          ))}
        </div>

        {/* TOMBOL REGISTER */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full border border-black bg-gray-100 py-2 mt-2 hover:bg-gray-200 transition-colors text-black text-sm sm:text-base"
        >
          {isLoading ? "Loading..." : "Register"}
        </button>

        {/* DIVIDER TEXT */}
        <div className="mt-4 mb-2 text-sm sm:text-base text-center">
          or continue with
        </div>

        {/* SOCIAL BUTTONS KOTAK */}
        <div className="w-full flex flex-col gap-0 mb-4">
          {socialProviders.map((provider) => (
            <button 
              key={provider.id}
              type="button" 
              onClick={() => handleSocialRegister(provider.id)} 
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 border border-black bg-gray-100 py-2 -mt-[1px] hover:bg-gray-200 transition-colors text-sm sm:text-base disabled:opacity-50"
            >
              {provider.icon} Continue with {provider.name}
            </button>
          ))}
        </div>

        {/* LINK LOGIN */}
        <div className="text-sm sm:text-base text-center mt-2">
          Already have an account? 
          <Link href="/login" className="text-purple-800 underline ml-1 hover:text-purple-600">
            Login here
          </Link>
        </div>

      </form>
    </div>
  );
}