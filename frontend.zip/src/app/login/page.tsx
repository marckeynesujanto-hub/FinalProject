"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signIn } from "next-auth/react";
import { FcGoogle } from "react-icons/fc";
import {
  FaEnvelope,
  FaLock,
  FaEye,
  FaEyeSlash,
  FaApple,
  FaWindows,
} from "react-icons/fa";

export default function LoginPage() {
  const router = useRouter();

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const socialProviders = [
    { id: "google", name: "Google", icon: <FcGoogle className="text-xl" /> },
    { id: "apple", name: "Apple", icon: <FaApple className="text-xl" /> },
    { id: "microsoft", name: "Microsoft", icon: <FaWindows className="text-xl" /> },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const apiUrl =
        process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

      const response = await fetch(`${apiUrl}/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Login gagal");
      }

      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialLogin = (providerId: string) => {
    signIn(providerId, {
      callbackUrl: "/dashboard",
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white text-black p-4">
      <form
        onSubmit={handleLogin}
        className="w-full max-w-[400px] flex flex-col items-center"
      >
        <h1 className="text-3xl font-bold mb-6 uppercase">LOGIN</h1>

        {error && (
          <div className="w-full mb-4 p-2 bg-red-100 border border-red-500 text-red-700 text-center">
            {error}
          </div>
        )}

        <div className="w-full flex flex-col gap-0 mb-2">
          <div className="border border-black flex items-center">
            <div className="w-10 flex justify-center">
              <FaEnvelope />
            </div>

            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full py-2 px-2 outline-none"
            />
          </div>

          <div className="border border-black flex items-center -mt-[1px]">
            <div className="w-10 flex justify-center">
              <FaLock />
            </div>

            <input
              type={showPassword ? "text" : "password"}
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              className="w-full py-2 px-2 outline-none"
            />

            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="px-3"
            >
              {showPassword ? <FaEye /> : <FaEyeSlash />}
            </button>
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full border border-black py-2 mt-2"
        >
          {isLoading ? "Loading..." : "Login"}
        </button>

        <div className="mt-4 mb-2">or continue with</div>

        <div className="w-full flex flex-col gap-0">
          {socialProviders.map((provider) => (
            <button
              key={provider.id}
              type="button"
              onClick={() => handleSocialLogin(provider.id)}
              className="w-full border border-black py-2 flex items-center justify-center gap-2 -mt-[1px]"
            >
              {provider.icon}
              Continue with {provider.name}
            </button>
          ))}
        </div>

        <div className="mt-4">
          Don't have an account?
          <Link
            href="/register"
            className="ml-1 text-purple-700 underline"
          >
            Register here
          </Link>
        </div>
      </form>
    </div>
  );
}