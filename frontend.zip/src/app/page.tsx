"use client";

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';

export default function SplashScreen() {
  const router = useRouter();

  useEffect(() => {
    const timeout = setTimeout(() => {
      router.push('/login');
    }, 3000);
    return () => clearTimeout(timeout);
  }, [router]);

  return (
    <main className="min-h-screen bg-gray-200 flex items-center justify-center">
      <div className="relative w-full max-w-[430px] h-[100dvh] shadow-2xl overflow-hidden flex flex-col justify-end items-center pb-12 bg-white">
        
        {/* GAMBAR BACKGROUND - Tanpa clip-path agar tidak ada hitam */}
        <Image 
          src="/images/loadingscreen.jpg" // Tambahkan ?v=2 di belakang nama file
          alt="Trashin Splash" 
          fill
          className="object-cover object-center z-0"
          priority
        />

        {/* LOADING SPINNER - Z-index ditingkatkan agar tidak tertutup */}
        <div className="mb-8 z-10">
          <div className="animate-spin rounded-full h-10 w-10 border-4 border-teal-600 border-t-transparent shadow-lg"></div>
        </div>

        {/* TEKS KELOMPOK 9 */}
        <div className="z-10 text-center">
          <p className="text-teal-800 text-sm font-medium">Powered by</p>
          <p className="text-teal-950 text-lg font-bold">Kelompok 9</p>
        </div>

      </div>
    </main>
  );
}