export default function SplashPage() {
    return (
      <main className="min-h-screen bg-gradient-to-b from-cyan-600 to-green-100 flex flex-col items-center justify-center">
  
        <div className="text-center">
          <div className="w-40 h-40 bg-white rounded-full mx-auto"></div>
  
          <h1 className="text-5xl font-bold text-blue-700 mt-5">
            TRASHIN
          </h1>
        </div>
  
        <div className="mt-20">
          <div className="w-10 h-10 border-4 border-black border-t-transparent rounded-full animate-spin"></div>
        </div>
  
        <div className="absolute bottom-10 text-center">
          <p className="font-semibold">Powered by</p>
  
          <h2 className="text-2xl">
            Kelompok 7
          </h2>
        </div>
      </main>
    );
  }