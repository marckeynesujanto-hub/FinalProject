import React from 'react';
import { FaUser, FaEnvelope, FaIdCard, FaEdit } from 'react-icons/fa';

// 1. Fungsi Data-Driven: Mengambil data profil dari Database
async function getProfileData() {
  // Simulasi fetch data dari database berdasarkan session user
  await new Promise((resolve) => setTimeout(resolve, 400));
  
  return {
    fullName: "Ferdinand Thionardi",
    email: "ferdinand@example.com",
    memberId: "TRASH-2026-001",
    joinedDate: "Mei 2026",
    avatarUrl: null, // Bisa diisi URL gambar jika ada
  };
}

export default async function ProfilePage() {
  const user = await getProfileData();

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-md mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Profil Saya</h1>

        {/* PROFIL CARD */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-200">
          <div className="flex flex-col items-center mb-6">
            <div className="w-24 h-24 bg-teal-100 rounded-full flex items-center justify-center mb-4">
              <FaUser className="text-4xl text-teal-700" />
            </div>
            <h2 className="text-xl font-black text-gray-800">{user.fullName}</h2>
            <p className="text-sm text-gray-500">Member Sejak {user.joinedDate}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center p-4 bg-gray-50 rounded-2xl">
              <FaEnvelope className="text-gray-400 mr-4" />
              <div>
                <p className="text-[10px] uppercase font-bold text-gray-400">Email</p>
                <p className="font-semibold text-gray-700">{user.email}</p>
              </div>
            </div>

            <div className="flex items-center p-4 bg-gray-50 rounded-2xl">
              <FaIdCard className="text-gray-400 mr-4" />
              <div>
                <p className="text-[10px] uppercase font-bold text-gray-400">Member ID</p>
                <p className="font-semibold text-gray-700">{user.memberId}</p>
              </div>
            </div>
          </div>

          <button className="w-full mt-8 py-4 bg-teal-700 text-white font-bold rounded-2xl hover:bg-teal-800 transition flex items-center justify-center gap-2">
            <FaEdit /> Edit Profil
          </button>
        </div>
      </div>
    </div>
  );
}