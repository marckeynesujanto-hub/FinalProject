'use client'

import Link from 'next/link'
import { Recycle, ArrowRight } from 'lucide-react'

export default function SplashScreen() {
  return (
    <div className="min-h-screen bg-[#0a0f0a] flex flex-col items-center justify-center text-white relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(#22c55e_0.8px,transparent_1px)] bg-[length:4px_4px] opacity-20" />
      
      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center mb-4 shadow-2xl shadow-green-500/50">
            <Recycle className="w-14 h-14 text-white" />
          </div>
          <div className="text-6xl font-bold tracking-tighter">THRASHIN</div>
          <div className="text-green-400 text-sm tracking-[4px] mt-1">SMART WASTE • 2026</div>
        </div>

        <h1 className="text-4xl font-semibold leading-tight max-w-[280px]">
          Turn your waste<br />into <span className="text-green-400">rewards</span>
        </h1>
        
        <p className="mt-4 text-lg text-gray-400 max-w-[260px]">
          Earn points, get waste picked up, and shop sustainable products.
        </p>

        <div className="mt-12 w-full max-w-[280px] space-y-3">
          <Link 
            href="/login"
            className="block w-full py-4 bg-white text-black font-semibold rounded-2xl text-center active:scale-[0.985] transition-all"
          >
            Get Started
          </Link>
          
          <Link 
            href="/dashboard"
            className="block w-full py-4 border border-white/30 text-white font-medium rounded-2xl text-center flex items-center justify-center gap-2 hover:bg-white/5 active:bg-white/10"
          >
            Continue as Guest <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>

      <div className="absolute bottom-8 text-center text-xs text-gray-500">
        Powered by Kelompok • Jakarta
      </div>
    </div>
  )
}
