'use client'

import BottomNav from '@/components/BottomNav'
import { ArrowLeft, Package } from 'lucide-react'
import Link from 'next/link'

const mockOrders = [
  {
    id: "ORD-28471",
    date: "May 10, 2026",
    status: "DELIVERED",
    total: 134000,
    items: 2,
    products: ["Upcycled Denim Tote Bag", "Bamboo Toothbrush Set"]
  },
  {
    id: "ORD-28392",
    date: "May 3, 2026",
    status: "SHIPPED",
    total: 65000,
    items: 1,
    products: ["Recycled Ocean Plastic Notebook"]
  }
]

export default function OrdersPage() {
  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="sticky top-0 z-40 bg-white border-b px-4 py-4 flex items-center gap-3">
        <Link href="/dashboard">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="font-semibold text-xl">Order History</h1>
      </div>

      <div className="px-4 pt-6 space-y-4">
        {mockOrders.map((order, index) => (
          <div key={index} className="eco-card p-5">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-mono text-sm text-gray-500">{order.id}</div>
                <div className="font-semibold mt-1">{order.date}</div>
              </div>
              <div className={`px-3 py-1 text-xs rounded-full font-medium ${order.status === 'DELIVERED' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                {order.status}
              </div>
            </div>

            <div className="mt-4 text-sm text-gray-600">
              {order.items} items • {order.products.join(", ")}
            </div>

            <div className="flex justify-between items-center mt-4 pt-4 border-t">
              <div className="font-semibold text-lg">Rp.{order.total.toLocaleString('id-ID')}</div>
              <button className="text-green-600 text-sm font-medium">View Details →</button>
            </div>
          </div>
        ))}
      </div>

      <BottomNav />
    </div>
  )
}
