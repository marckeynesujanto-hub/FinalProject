'use client'

import { useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { 
  Truck, 
  Recycle, 
  MapPin, 
  Gift, 
  ArrowRight,
  Bell 
} from 'lucide-react'
import Link from 'next/link'

export default function Dashboard() {
  const [user] = useState({
    name: "Pablo Ferdiansyah",
    points: 1240800,
    level: 3,
    avatar: "https://i.pravatar.cc/150?u=pablo"
  })

  const quickActions = [
    {
      id: 'trashdel',
      title: 'TrashDel',
      subtitle: 'Jemput Sampah',
      icon: Truck,
      color: 'bg-green-600',
      href: '/subscription'
    },
    {
      id: 'trashout',
      title: 'TrashOut',
      subtitle: 'Antar ke Drop Point',
      icon: Recycle,
      color: 'bg-emerald-600',
      href: '/map'
    },
    {
      id: 'trashmaps',
      title: 'TrashMaps',
      subtitle: 'Cari Lokasi',
      icon: MapPin,
      color: 'bg-teal-600',
      href: '/map'
    }
  ]

  const promos = [
    {
      id: 1,
      title: "Save 13k with code 'NEWCOMER'",
      subtitle: "Tap here to apply the promo. Let's TrashDel!",
      color: "bg-green-600",
      icon: Gift
    },
    {
      id: 2,
      title: "2 WEEKS FREE SUBSCRIPTION",
      subtitle: "Get your first 2 weeks free now!",
      color: "bg-lime-600",
      icon: Gift
    }
  ]

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      {/* Top Bar */}
      <div className="sticky top-0 z-40 bg-white border-b px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-green-600 flex items-center justify-center">
            <Recycle className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-semibold text-lg">ThrashIn</div>
            <div className="text-[10px] text-gray-500 -mt-1">Smart Waste</div>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="p-2 rounded-full bg-gray-100">
            <Bell className="w-5 h-5 text-gray-600" />
          </button>
          <img 
            src={user.avatar} 
            alt="Profile" 
            className="w-9 h-9 rounded-full border-2 border-green-500" 
          />
        </div>
      </div>

      <div className="px-4 pt-6 space-y-6">
        {/* Greeting */}
        <div>
          <p className="text-gray-500 text-sm">Good morning,</p>
          <h1 className="text-2xl font-semibold">{user.name.split(' ')[0]} 👋</h1>
        </div>

        {/* Balance Card - Exact match to reference */}
        <div className="balance-card p-6 text-white relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                <span className="text-sm opacity-90">Available balance</span>
              </div>
              <div className="text-4xl font-semibold tracking-tighter">
                Rp.{user.points.toLocaleString('id-ID')}
              </div>
              <div className="text-sm opacity-75 mt-1">+ Rp.45.000 from last week</div>
            </div>
            
            <div className="text-right">
              <div className="inline-flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full text-xs">
                Level {user.level}
              </div>
            </div>
          </div>

          <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-white/10 rounded-full" />
          <div className="absolute -bottom-10 -right-2 w-24 h-24 bg-white/10 rounded-full" />
        </div>

        {/* Quick Actions Grid */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="font-semibold text-lg">Quick Actions</h2>
            <Link href="/map" className="text-sm text-green-600 flex items-center gap-1">
              See all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon
              return (
                <Link 
                  key={action.id}
                  href={action.href}
                  className="action-btn eco-card p-4 flex flex-col items-center text-center hover:shadow-xl active:scale-[0.985]"
                >
                  <div className={`${action.color} w-14 h-14 rounded-2xl flex items-center justify-center mb-3`}>
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <div className="font-semibold text-sm">{action.title}</div>
                  <div className="text-[10px] text-gray-500 mt-0.5">{action.subtitle}</div>
                </Link>
              )
            })}
          </div>
        </div>

        {/* Promotional Banners */}
        <div className="space-y-3">
          <h2 className="font-semibold text-lg px-1">Special Offers</h2>
          
          {promos.map((promo, index) => (
            <div 
              key={index}
              className={`${promo.color} text-white rounded-3xl p-5 flex items-center gap-4 active:scale-[0.985] transition-all cursor-pointer`}
            >
              <div className="flex-1">
                <div className="font-semibold text-lg leading-tight">{promo.title}</div>
                <div className="text-sm opacity-90 mt-1">{promo.subtitle}</div>
              </div>
              <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                <promo.icon className="w-6 h-6" />
              </div>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div>
          <div className="flex items-center justify-between mb-3 px-1">
            <h2 className="font-semibold text-lg">Recent Activity</h2>
            <span className="text-xs text-green-600">View all</span>
          </div>

          <div className="eco-card p-4 space-y-4">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                <Truck className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium">TrashDel completed</div>
                <div className="text-xs text-gray-500">2.8kg • +28 points • 2 days ago</div>
              </div>
              <div className="text-right text-sm font-medium text-green-600">+28</div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Recycle className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="flex-1">
                <div className="font-medium">Dropped off at Kemang Eco Station</div>
                <div className="text-xs text-gray-500">1.4kg organic • +14 points • 5 days ago</div>
              </div>
              <div className="text-right text-sm font-medium text-green-600">+14</div>
            </div>
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
