'use client'

import BottomNav from '@/components/BottomNav'
import { User, Settings, LogOut, Award, History } from 'lucide-react'
import Link from 'next/link'

export default function ProfilePage() {
  const user = {
    name: "Pablo Ferdiansyah",
    email: "pablo@thrashin.id",
    points: 1240800,
    level: 3,
    totalWaste: 124.5,
    joinDate: "March 2025"
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="bg-green-600 text-white px-4 pt-8 pb-10">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
            <User className="w-8 h-8" />
          </div>
          <div>
            <div className="font-semibold text-2xl">{user.name}</div>
            <div className="text-green-200 text-sm">{user.email}</div>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-6">
        <div className="eco-card p-5 mb-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-semibold text-green-600">{user.points.toLocaleString()}</div>
              <div className="text-xs text-gray-500">Points</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-green-600">Level {user.level}</div>
              <div className="text-xs text-gray-500">Eco Warrior</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-green-600">{user.totalWaste}kg</div>
              <div className="text-xs text-gray-500">Waste Saved</div>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <Link href="/leaderboard" className="flex items-center gap-4 eco-card p-4 active:bg-gray-50">
            <Award className="w-5 h-5 text-amber-500" />
            <div className="flex-1">Leaderboard & Badges</div>
            <div className="text-gray-400">→</div>
          </Link>

          <Link href="/orders" className="flex items-center gap-4 eco-card p-4 active:bg-gray-50">
            <History className="w-5 h-5 text-blue-500" />
            <div className="flex-1">Order History</div>
            <div className="text-gray-400">→</div>
          </Link>

          <div className="flex items-center gap-4 eco-card p-4 active:bg-gray-50">
            <Settings className="w-5 h-5 text-gray-500" />
            <div className="flex-1">Settings & Preferences</div>
            <div className="text-gray-400">→</div>
          </div>

          <button 
            onClick={() => window.location.href = '/'}
            className="w-full flex items-center gap-4 eco-card p-4 text-red-600 active:bg-red-50 mt-4"
          >
            <LogOut className="w-5 h-5" />
            <div className="flex-1 text-left">Sign Out</div>
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
