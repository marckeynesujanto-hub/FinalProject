'use client'

import Link from 'next/link'
import { useState } from 'react'
import { ArrowLeft } from 'lucide-react'

export default function RegisterPage() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: ''
  })

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
        }),
      })

      const data = await res.json()

      if (res.ok) {
        alert("🎉 Account created successfully! Please login.")
        window.location.href = '/login'
      } else {
        alert(data.error || "Registration failed")
      }
    } catch (error) {
      alert("Something went wrong. Please try again.")
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="px-4 pt-6">
        <Link href="/login" className="inline-flex items-center gap-2 text-sm text-gray-500">
          <ArrowLeft className="w-4 h-4" /> Back to login
        </Link>
      </div>

      <div className="flex-1 px-6 pt-8">
        <div className="max-w-sm mx-auto">
          <h1 className="text-3xl font-semibold">Create your account</h1>
          <p className="text-gray-500 mt-2">Join 124,082 eco-warriors making a difference</p>

          <form onSubmit={handleRegister} className="mt-8 space-y-4">
            <div>
              <label className="text-sm text-gray-600">Your name</label>
              <input
                type="text"
                placeholder="Enter your name"
                value={form.name}
                onChange={(e) => setForm({...form, name: e.target.value})}
                className="mt-1.5 w-full py-3.5 px-4 bg-gray-100 rounded-2xl border-0 focus:ring-2 focus:ring-green-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-sm text-gray-600">E-mail or phone number</label>
              <input
                type="text"
                placeholder="Type your e-mail or phone number"
                value={form.email}
                onChange={(e) => setForm({...form, email: e.target.value})}
                className="mt-1.5 w-full py-3.5 px-4 bg-gray-100 rounded-2xl border-0 focus:ring-2 focus:ring-green-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="text-sm text-gray-600">Password</label>
              <input
                type="password"
                placeholder="Type your password"
                value={form.password}
                onChange={(e) => setForm({...form, password: e.target.value})}
                className="mt-1.5 w-full py-3.5 px-4 bg-gray-100 rounded-2xl border-0 focus:ring-2 focus:ring-green-500 outline-none"
                required
              />
              <p className="text-xs text-gray-400 mt-1">*Must be 8 characters at least</p>
            </div>

            <div className="flex items-start gap-2 text-xs text-gray-500 pt-2">
              <input type="checkbox" className="mt-1" required />
              <span>By creating an account means you agree to the Terms and Conditions, and our Privacy policy</span>
            </div>

            <button 
              type="submit"
              className="w-full py-4 bg-black text-white font-semibold rounded-2xl mt-4 active:bg-gray-900"
            >
              Sign in
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            or do it via another account
          </div>

          <div className="flex justify-center gap-4 mt-4">
            {['G', '', 'M'].map((icon, i) => (
              <button 
                key={i}
                onClick={() => window.location.href = '/dashboard'}
                className="w-14 h-14 border rounded-2xl flex items-center justify-center text-2xl hover:bg-gray-50"
              >
                {icon}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
