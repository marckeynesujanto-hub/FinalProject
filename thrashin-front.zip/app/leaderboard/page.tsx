'use client'

import { useEffect, useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { Trophy, Award } from 'lucide-react'

interface LeaderboardUser {
  rank: number
  name: string
  points: number
  avatarUrl?: string
  badge: string
  level: number
}

export default function LeaderboardPage() {
  const [leaderboard, setLeaderboard] = useState<LeaderboardUser[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Fetch from our API
    fetch('/api/leaderboard')
      .then(res => res.json())
      .then(data => {
        setLeaderboard(data.leaderboard || [])
        setLoading(false)
      })
      .catch(() => {
        // Fallback mock data
        setLeaderboard([
          { rank: 1, name: "Sinta Wijaya", points: 5840, badge: "🌍 Eco Legend", level: 7 },
          { rank: 2, name: "Budi Santoso", points: 4720, badge: "♻️ Recycling Hero", level: 6 },
          { rank: 3, name: "Rina Marlina", points: 3910, badge: "🌱 Green Champion", level: 5 },
          { rank: 4, name: "Pablo Ferdiansyah", points: 1240, badge: "🍃 Waste Warrior", level: 3 },
          { rank: 5, name: "Andi Pratama", points: 980, badge: "🌿 Eco Beginner", level: 2 },
        ])
        setLoading(false)
      })
  }, [])

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="sticky top-0 z-40 bg-white border-b px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Trophy className="w-6 h-6 text-amber-500" />
          <h1 className="text-xl font-semibold">Monthly Leaderboard</h1>
        </div>
        <div className="text-xs bg-green-100 text-green-700 px-3 py-1 rounded-full">May 2026</div>
      </div>

      <div className="px-4 pt-6">
        {/* Top 3 Podium */}
        <div className="flex justify-center items-end gap-3 mb-8">
          {leaderboard.slice(0, 3).map((user, index) => (
            <div key={index} className={`text-center ${index === 0 ? 'scale-110' : ''}`}>
              <div className="relative mx-auto mb-2">
                <img 
                  src={`https://i.pravatar.cc/80?u=${user.name}`} 
                  className="w-16 h-16 rounded-full border-4 border-white shadow-xl mx-auto" 
                />
                <div className="absolute -top-1 -right-1 w-7 h-7 bg-amber-400 rounded-full flex items-center justify-center text-xs font-bold text-white">
                  {user.rank}
                </div>
              </div>
              <div className="font-semibold text-sm">{user.name.split(' ')[0]}</div>
              <div className="text-xs text-green-600 font-medium">{user.points.toLocaleString()} pts</div>
            </div>
          ))}
        </div>

        {/* Full List */}
        <div className="eco-card overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-gray-400">Loading rankings...</div>
          ) : (
            leaderboard.map((user, index) => (
              <div 
                key={index} 
                className={`flex items-center gap-4 px-5 py-4 border-b last:border-b-0 ${user.name.includes('Pablo') ? 'bg-green-50' : ''}`}
              >
                <div className="w-8 text-center font-mono text-lg font-medium text-gray-400">
                  {user.rank}
                </div>
                
                <img 
                  src={`https://i.pravatar.cc/48?u=${user.name}`} 
                  className="w-11 h-11 rounded-full" 
                />
                
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{user.name}</div>
                  <div className="text-xs text-gray-500 flex items-center gap-1">
                    {user.badge} • Level {user.level}
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-semibold text-green-600">{user.points.toLocaleString()}</div>
                  <div className="text-[10px] text-gray-400">points</div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="text-center text-xs text-gray-400 mt-6">
          Leaderboard resets on the 1st of every month
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
