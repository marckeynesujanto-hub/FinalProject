'use client'

import { useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { ArrowLeft, Calendar, Truck } from 'lucide-react'
import Link from 'next/link'

export default function SubscriptionPage() {
  const [form, setForm] = useState({
    planType: 'weekly',
    pickupDays: ['MONDAY', 'THURSDAY'],
    wasteTypes: ['MIXED'],
    price: 45000
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const days = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']
  const wasteOptions = ['ORGANIC', 'INORGANIC', 'MIXED']

  const toggleDay = (day: string) => {
    if (form.pickupDays.includes(day)) {
      setForm({ ...form, pickupDays: form.pickupDays.filter(d => d !== day) })
    } else {
      setForm({ ...form, pickupDays: [...form.pickupDays, day] })
    }
  }

  const toggleWaste = (type: string) => {
    if (form.wasteTypes.includes(type)) {
      setForm({ ...form, wasteTypes: form.wasteTypes.filter(t => t !== type) })
    } else {
      setForm({ ...form, wasteTypes: [...form.wasteTypes, type] })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Demo user ID (from seed)
    const userId = "cm9v0p5x00000v8g8k0z0z0z0" // Replace with real user ID after auth

    try {
      const res = await fetch('/api/subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          planType: form.planType,
          pickupDays: form.pickupDays,
          wasteTypes: form.wasteTypes,
          price: form.price,
        }),
      })

      if (res.ok) {
        setSuccess(true)
        setTimeout(() => {
          window.location.href = '/dashboard'
        }, 2000)
      } else {
        alert("Failed to create subscription")
      }
    } catch (error) {
      alert("Error creating subscription")
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-green-50">
        <div className="text-center">
          <div className="text-6xl mb-4">🎉</div>
          <h1 className="text-2xl font-semibold text-green-700">Subscription Created!</h1>
          <p className="text-gray-600 mt-2">Your first pickup is scheduled. Check your dashboard.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="sticky top-0 z-40 bg-white border-b px-4 py-4 flex items-center gap-3">
        <Link href="/dashboard">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="font-semibold text-xl">New Subscription</h1>
          <p className="text-xs text-gray-500">Weekly waste pickup service</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="px-4 pt-6 space-y-6">
        {/* Plan Type */}
        <div className="eco-card p-5">
          <div className="font-semibold mb-3 flex items-center gap-2">
            <Truck className="w-5 h-5 text-green-600" /> Choose Plan
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            {[
              { type: 'weekly', label: 'Weekly', price: 'Rp45.000' },
              { type: 'biweekly', label: 'Bi-weekly', price: 'Rp75.000' },
              { type: 'monthly', label: 'Monthly', price: 'Rp120.000' }
            ].map((plan) => (
              <button
                key={plan.type}
                type="button"
                onClick={() => setForm({ ...form, planType: plan.type, price: parseInt(plan.price.replace(/\D/g, '')) })}
                className={`p-4 rounded-2xl border text-left transition-all ${form.planType === plan.type ? 'border-green-600 bg-green-50' : 'border-gray-200'}`}
              >
                <div className="font-semibold">{plan.label}</div>
                <div className="text-sm text-gray-500">{plan.price}/mo</div>
              </button>
            ))}
          </div>
        </div>

        {/* Pickup Days */}
        <div className="eco-card p-5">
          <div className="font-semibold mb-3 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-green-600" /> Pickup Days
          </div>
          <p className="text-sm text-gray-500 mb-3">Select at least 1 day per week</p>
          
          <div className="flex flex-wrap gap-2">
            {days.map(day => (
              <button
                key={day}
                type="button"
                onClick={() => toggleDay(day)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${form.pickupDays.includes(day) 
                  ? 'bg-green-600 text-white' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
              >
                {day.slice(0, 3)}
              </button>
            ))}
          </div>
        </div>

        {/* Waste Types */}
        <div className="eco-card p-5">
          <div className="font-semibold mb-3">Waste Types Accepted</div>
          <div className="flex gap-3">
            {wasteOptions.map(type => (
              <button
                key={type}
                type="button"
                onClick={() => toggleWaste(type)}
                className={`flex-1 py-3 rounded-2xl border text-sm font-medium ${form.wasteTypes.includes(type) 
                  ? 'bg-green-600 text-white border-green-600' 
                  : 'border-gray-200'}`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Summary */}
        <div className="eco-card p-5 bg-green-600 text-white">
          <div className="flex justify-between items-center">
            <div>
              <div className="text-sm opacity-75">Monthly Total</div>
              <div className="text-3xl font-semibold">Rp.{form.price.toLocaleString('id-ID')}</div>
            </div>
            <div className="text-right text-sm">
              Starts today<br />
              <span className="opacity-75">Cancel anytime</span>
            </div>
          </div>
        </div>

        <button 
          type="submit"
          disabled={loading || form.pickupDays.length === 0}
          className="w-full py-4 bg-black text-white font-semibold rounded-2xl disabled:opacity-50 active:bg-gray-900"
        >
          {loading ? "Creating Subscription..." : "Subscribe Now"}
        </button>

        <p className="text-center text-xs text-gray-400">You can pause or cancel anytime from your dashboard</p>
      </form>

      <BottomNav />
    </div>
  )
}
