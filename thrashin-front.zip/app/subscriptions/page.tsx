'use client'

import { useState, useEffect } from 'react'
import BottomNav from '@/components/BottomNav'
import { ArrowLeft, Pause, Play, Calendar, Trash2 } from 'lucide-react'
import Link from 'next/link'

interface Subscription {
  id: string
  planType: string
  status: string
  pickupDays: string[]
  price: number
  pausedUntil?: string
  schedules: any[]
}

export default function SubscriptionsPage() {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [loading, setLoading] = useState(true)

  const fetchSubscriptions = async () => {
    // Demo user ID
    const res = await fetch('/api/subscriptions?userId=cm9v0p5x00000v8g8k0z0z0z0')
    const data = await res.json()
    setSubscriptions(data.subscriptions || [])
    setLoading(false)
  }

  useEffect(() => {
    fetchSubscriptions()
  }, [])

  const togglePause = async (subId: string, currentStatus: string) => {
    const action = currentStatus === 'ACTIVE' ? 'pause' : 'resume'
    
    const res = await fetch(`/api/subscriptions/${subId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action }),
    })

    if (res.ok) {
      fetchSubscriptions()
    }
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="sticky top-0 z-40 bg-white border-b px-4 py-4 flex items-center gap-3">
        <Link href="/dashboard">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="font-semibold text-xl">My Subscriptions</h1>
      </div>

      <div className="px-4 pt-6">
        {loading ? (
          <div className="text-center py-12 text-gray-400">Loading your plans...</div>
        ) : subscriptions.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📭</div>
            <h3 className="font-semibold text-xl">No active subscriptions</h3>
            <p className="text-gray-500 mt-2">Start a weekly pickup plan today</p>
            <Link href="/subscription" className="inline-block mt-6 bg-green-600 text-white px-8 py-3 rounded-2xl font-semibold">
              Create New Plan
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {subscriptions.map((sub) => (
              <div key={sub.id} className="eco-card p-5">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className="font-semibold text-lg capitalize">{sub.planType} Plan</div>
                    <div className="text-sm text-gray-500">Rp.{sub.price.toLocaleString('id-ID')}/month</div>
                  </div>
                  
                  <div className={`px-3 py-1 rounded-full text-xs font-medium ${sub.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                    {sub.status}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {sub.pickupDays.map(day => (
                    <div key={day} className="bg-gray-100 px-3 py-1 rounded-full text-xs">{day}</div>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button 
                    onClick={() => togglePause(sub.id, sub.status)}
                    className="flex-1 flex items-center justify-center gap-2 py-3 border rounded-2xl text-sm font-medium"
                  >
                    {sub.status === 'ACTIVE' ? (
                      <><Pause className="w-4 h-4" /> Pause</>
                    ) : (
                      <><Play className="w-4 h-4" /> Resume</>
                    )}
                  </button>
                  
                  <Link href={`/subscription?edit=${sub.id}`} className="flex-1 flex items-center justify-center gap-2 py-3 border border-green-600 text-green-600 rounded-2xl text-sm font-medium">
                    <Calendar className="w-4 h-4" /> Manage
                  </Link>
                </div>

                {sub.schedules?.length > 0 && (
                  <div className="mt-4 pt-4 border-t text-xs text-gray-500">
                    Next pickup: {new Date(sub.schedules[0].scheduledDate).toLocaleDateString('id-ID', { weekday: 'long', month: 'short', day: 'numeric' })}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
