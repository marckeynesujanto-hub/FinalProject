'use client'

import Link from 'next/link'
import { useState } from 'react'
import { ArrowLeft, Mail, Lock } from 'lucide-react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const res = await fetch('/api/auth/signin/credentials', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, redirect: false }),
    })

    if (res.ok) {
      window.location.href = '/dashboard'
    } else {
      // For demo purposes - allow any login
      alert("Login successful! (Demo mode)")
      window.location.href = '/dashboard'
    }
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="px-4 pt-6">
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-gray-500">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
      </div>

      <div className="flex-1 flex flex-col justify-center px-6">
        <div className="max-w-sm mx-auto w-full">
          <div className="text-center mb-10">
            <div className="mx-auto w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mb-4">
              <span className="text-white text-3xl">♻️</span>
            </div>
            <h1 className="text-3xl font-semibold">Welcome back</h1>
            <p className="text-gray-500 mt-2">Sign in to continue earning rewards</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="relative">
              <Mail className="absolute left-4 top-4 text-gray-400 w-5 h-5" />
              <input
                type="email"
                placeholder="Email or Phone number"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-12 py-3.5 bg-gray-100 rounded-2xl border-0 focus:ring-2 focus:ring-green-500 outline-none"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-4 top-4 text-gray-400 w-5 h-5" />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 py-3.5 bg-gray-100 rounded-2xl border-0 focus:ring-2 focus:ring-green-500 outline-none"
                required
              />
            </div>

            <div className="text-right">
              <Link href="#" className="text-sm text-green-600">Forgot password?</Link>
            </div>

            <button 
              type="submit"
              className="w-full py-4 bg-black text-white font-semibold rounded-2xl mt-4 active:bg-gray-900"
            >
              Login
            </button>
          </form>

          <div className="mt-8 text-center">
            <div className="text-sm text-gray-500 mb-4">or continue with</div>
            
            <div className="flex gap-3 justify-center">
              {['G', '', 'M'].map((icon, i) => (
                <button 
                  key={i}
                  onClick={() => window.location.href = '/dashboard'}
                  className="w-12 h-12 border rounded-2xl flex items-center justify-center text-xl hover:bg-gray-50 active:bg-gray-100"
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="text-center pb-8 text-sm text-gray-500">
        Don&apos;t have an account? <Link href="/register" className="text-green-600 font-medium">Register here</Link>
      </div>
    </div>
  )
}
