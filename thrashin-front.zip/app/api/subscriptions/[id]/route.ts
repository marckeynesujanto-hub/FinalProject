import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// PATCH /api/subscriptions/[id] - Update subscription (pause, resume, change days)
export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { action, pickupDays, pausedUntil, status } = body
    const subscriptionId = params.id

    let updateData: any = {}

    if (action === 'pause') {
      updateData = {
        status: 'PAUSED',
        pausedUntil: pausedUntil ? new Date(pausedUntil) : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      }
    } else if (action === 'resume') {
      updateData = {
        status: 'ACTIVE',
        pausedUntil: null,
      }
    } else if (pickupDays) {
      updateData.pickupDays = pickupDays
    } else if (status) {
      updateData.status = status
    }

    const updated = await prisma.subscription.update({
      where: { id: subscriptionId },
      data: updateData,
    })

    return NextResponse.json({ success: true, subscription: updated })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update subscription' }, { status: 500 })
  }
}
