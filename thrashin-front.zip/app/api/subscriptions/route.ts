import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { addDays, addMonths, startOfMonth, endOfMonth } from 'date-fns'

// POST /api/subscriptions - Create new subscription + auto-generate schedules
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, planType, pickupDays, wasteTypes, price, startDate } = body

    if (!userId || !planType || !pickupDays || !wasteTypes) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Create subscription
    const subscription = await prisma.subscription.create({
      data: {
        userId,
        planType,
        price: parseFloat(price),
        pickupDays: pickupDays as string[],
        wasteTypes: wasteTypes as string[],
        startDate: startDate ? new Date(startDate) : new Date(),
        status: 'ACTIVE',
      },
    })

    // Auto-generate next 60 days of schedules
    const schedulesToCreate = []
    let currentDate = new Date(subscription.startDate)

    for (let i = 0; i < 20; i++) { // ~2 months
      const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'long' }).toUpperCase()
      
      if (pickupDays.includes(dayName)) {
        schedulesToCreate.push({
          subscriptionId: subscription.id,
          scheduledDate: new Date(currentDate),
          status: 'SCHEDULED',
          wasteType: wasteTypes[0], // default to first type
        })
      }
      
      currentDate = addDays(currentDate, 1)
    }

    if (schedulesToCreate.length > 0) {
      await prisma.schedule.createMany({
        data: schedulesToCreate,
      })
    }

    return NextResponse.json({ 
      success: true, 
      subscription,
      message: `${schedulesToCreate.length} pickup schedules created automatically`
    }, { status: 201 })

  } catch (error) {
    console.error('Create subscription error:', error)
    return NextResponse.json({ error: 'Failed to create subscription' }, { status: 500 })
  }
}

// GET /api/subscriptions?userId=xxx - Get user's subscriptions
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const userId = searchParams.get('userId')

  if (!userId) {
    return NextResponse.json({ error: 'userId required' }, { status: 400 })
  }

  const subscriptions = await prisma.subscription.findMany({
    where: { userId },
    include: {
      schedules: {
        where: {
          scheduledDate: { gte: new Date() }
        },
        orderBy: { scheduledDate: 'asc' },
        take: 5
      }
    },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ subscriptions })
}
