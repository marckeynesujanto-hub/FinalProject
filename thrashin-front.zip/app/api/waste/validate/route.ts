import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// POST /api/waste/validate - Driver verifies waste & awards points (10 pts per 1kg)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      userId, 
      weightKg, 
      wasteType, 
      driverId, 
      driverName,
      scheduleId 
    } = body

    if (!userId || !weightKg || !wasteType) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const pointsToAward = Math.floor(weightKg * 10) // 10 points per 1kg

    // 1. Create WasteRecord
    const wasteRecord = await prisma.wasteRecord.create({
      data: {
        userId,
        weightKg: parseFloat(weightKg),
        wasteType,
        verifiedBy: driverId || 'system',
        verifiedAt: new Date(),
        pointsAwarded: pointsToAward,
        source: scheduleId ? 'subscription_pickup' : 'dropoff',
      },
    })

    // 2. Update User points + totalWasteKg
    const user = await prisma.user.update({
      where: { id: userId },
      data: {
        points: { increment: pointsToAward },
        totalWasteKg: { increment: parseFloat(weightKg) },
      },
    })

    // 3. Create PointTransaction log
    await prisma.pointTransaction.create({
      data: {
        userId,
        amount: pointsToAward,
        reason: 'WASTE_VALIDATION',
        description: `${weightKg}kg ${wasteType} waste validated`,
        referenceId: wasteRecord.id,
        balanceAfter: user.points,
      },
    })

    // 4. Update schedule if exists
    if (scheduleId) {
      await prisma.schedule.update({
        where: { id: scheduleId },
        data: {
          status: 'COMPLETED',
          actualWeight: parseFloat(weightKg),
          driverId,
          driverName,
        },
      })
    }

    // 5. Check for badge unlocks (simple logic)
    const newLevel = Math.floor(user.points / 500) + 1
    if (newLevel > user.level) {
      await prisma.user.update({
        where: { id: userId },
        data: { level: newLevel },
      })
    }

    return NextResponse.json({
      success: true,
      pointsAwarded: pointsToAward,
      newTotalPoints: user.points,
      wasteRecord,
      message: `+${pointsToAward} points awarded!`
    })

  } catch (error) {
    console.error('Waste validation error:', error)
    return NextResponse.json({ error: 'Failed to validate waste' }, { status: 500 })
  }
}
