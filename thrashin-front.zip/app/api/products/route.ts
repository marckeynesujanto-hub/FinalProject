import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/products?category=Upcycled&search=...
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  const search = searchParams.get('search')

  const where: any = { isActive: true }

  if (category) where.category = category
  if (search) {
    where.OR = [
      { name: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ]
  }

  const products = await prisma.product.findMany({
    where,
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ products })
}

// POST /api/products - Admin only (for now open)
export async function POST(request: NextRequest) {
  const body = await request.json()
  
  const product = await prisma.product.create({
    data: {
      name: body.name,
      description: body.description,
      price: parseFloat(body.price),
      category: body.category,
      imageUrl: body.imageUrl,
      stock: body.stock || 50,
    },
  })

  return NextResponse.json({ success: true, product }, { status: 201 })
}
