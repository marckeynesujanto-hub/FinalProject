import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { startOfMonth, endOfMonth } from 'date-fns'

// GET /api/leaderboard - Monthly leaderboard (auto-reset on 1st)
export async function GET(request: NextRequest) {
  const now = new Date()
  const monthStart = startOfMonth(now)
  const monthEnd = endOfMonth(now)

  // Get top 50 users by points this month
  const topUsers = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      avatarUrl: true,
      points: true,
      level: true,
      totalWasteKg: true,
    },
    orderBy: { points: 'desc' },
    take: 50,
  })

  // Add rank
  const leaderboard = topUsers.map((user, index) => ({
    ...user,
    rank: index + 1,
    badge: getBadgeForPoints(user.points),
  }))

  // Top 3 get special rewards (simulated)
  const topThree = leaderboard.slice(0, 3)

  return NextResponse.json({
    month: now.toLocaleString('default', { month: 'long', year: 'numeric' }),
    leaderboard,
    topThree,
    resetDate: new Date(now.getFullYear(), now.getMonth() + 1, 1),
    message: "Leaderboard resets on the 1st of every month",
  })
}

function getBadgeForPoints(points: number): string {
  if (points >= 5000) return "🌍 Eco Legend"
  if (points >= 2000) return "♻️ Recycling Hero"
  if (points >= 1000) return "🌱 Green Champion"
  if (points >= 500) return "🍃 Waste Warrior"
  return "🌿 Eco Beginner"
}
