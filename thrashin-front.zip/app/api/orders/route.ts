import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

// GET /api/orders?userId=xxx
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const userId = searchParams.get('userId')

  if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 })

  const orders = await prisma.order.findMany({
    where: { userId },
    include: { items: { include: { product: true } } },
    orderBy: { createdAt: 'desc' },
  })

  return NextResponse.json({ orders })
}

// POST /api/orders - Place new order
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, items, paymentMethod } = body

    if (!userId || !items || items.length === 0) {
      return NextResponse.json({ error: 'Invalid order data' }, { status: 400 })
    }

    // Calculate total
    let totalAmount = 0
    const orderItemsData = []

    for (const item of items) {
      const product = await prisma.product.findUnique({
        where: { id: item.productId },
      })

      if (!product || product.stock < item.quantity) {
        return NextResponse.json({ 
          error: `Product ${item.productId} out of stock` 
        }, { status: 400 })
      }

      const itemTotal = product.price * item.quantity
      totalAmount += itemTotal

      orderItemsData.push({
        productId: item.productId,
        quantity: item.quantity,
        unitPrice: product.price,
      })

      // Reduce stock
      await prisma.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.quantity } },
      })
    }

    // Create order
    const order = await prisma.order.create({
      data: {
        userId,
        totalAmount,
        paymentMethod: paymentMethod || 'MIDTRANS',
        status: 'PENDING',
        items: {
          create: orderItemsData,
        },
      },
      include: { items: { include: { product: true } } },
    })

    return NextResponse.json({
      success: true,
      order,
      message: 'Order placed successfully. Complete payment to confirm.',
    }, { status: 201 })

  } catch (error) {
    console.error('Create order error:', error)
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 })
  }
}
