'use client'

import { useEffect, useRef, useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { Search, Navigation, X } from 'lucide-react'
import 'mapbox-gl/dist/mapbox-gl.css'

const MAPBOX_TOKEN = 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw'

interface Bin {
  id: number
  name: string
  address: string
  distance: string
  type: string
  fill: number
  lat: number
  lng: number
}

const smartBins: Bin[] = [
  { id: 1, name: "Binus University Drop Point", address: "Jl. K.H. Syahdan No.9, Palmerah", distance: "1.2 km", type: "MIXED", fill: 87, lat: -6.2019, lng: 106.7819 },
  { id: 2, name: "Kemang Eco Station", address: "Jl. Kemang Raya No. 45", distance: "3.8 km", type: "ORGANIC", fill: 42, lat: -6.2605, lng: 106.8134 },
  { id: 3, name: "SCBD Recycling Hub", address: "Jl. Jend. Sudirman No. 52", distance: "4.5 km", type: "INORGANIC", fill: 156, lat: -6.2253, lng: 106.8095 },
]

export default function MapPage() {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<any>(null)
  const [selectedBin, setSelectedBin] = useState<Bin | null>(null)

  useEffect(() => {
    if (map.current || !mapContainer.current) return

    // @ts-ignore
    const mapboxgl = require('mapbox-gl')
    mapboxgl.accessToken = MAPBOX_TOKEN

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [106.801, -6.22],
      zoom: 12,
      pitch: 45,
    })

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right')

    smartBins.forEach((bin) => {
      const el = document.createElement('div')
      el.className = 'w-9 h-9 bg-white rounded-full shadow-xl flex items-center justify-center border-4 border-green-500 cursor-pointer text-xl'
      el.innerHTML = '♻️'
      el.onclick = () => setSelectedBin(bin)

      new mapboxgl.Marker(el)
        .setLngLat([bin.lng, bin.lat])
        .addTo(map.current)
    })

    new mapboxgl.Marker({ color: '#3b82f6' })
      .setLngLat([106.801, -6.22])
      .addTo(map.current)

  }, [])

  return (
    <div className="min-h-screen bg-black pb-20 relative">
      <div className="absolute top-0 left-0 right-0 z-50 px-4 pt-4">
        <div className="relative">
          <div className="absolute left-4 top-3.5 text-gray-400">
            <Search className="w-5 h-5" />
          </div>
          <input 
            type="text" 
            placeholder="Search drop points or addresses..." 
            className="w-full pl-12 py-3.5 bg-white rounded-2xl shadow-2xl text-sm" 
          />
        </div>
      </div>

      <div ref={mapContainer} className="h-[70vh] w-full" />

      {selectedBin && (
        <div className="absolute bottom-20 left-0 right-0 z-50 px-4">
          <div className="eco-card p-5 relative">
            <button 
              onClick={() => setSelectedBin(null)}
              className="absolute top-4 right-4 text-gray-400"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="font-semibold text-xl pr-8">{selectedBin.name}</div>
            <div className="text-sm text-gray-500 mt-1">{selectedBin.address}</div>

            <div className="flex items-center gap-4 mt-4">
              <div className="px-4 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                {selectedBin.type}
              </div>
              <div className="text-sm text-gray-500">{selectedBin.distance} away • {selectedBin.fill}% full</div>
            </div>

            <div className="flex gap-3 mt-5">
              <button 
                onClick={() => alert(`🧭 Navigation started to ${selectedBin.name}`)}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3.5 rounded-2xl font-semibold flex items-center justify-center gap-2"
              >
                <Navigation className="w-4 h-4" /> Start Navigation
              </button>
              <button className="px-6 border border-green-600 text-green-600 rounded-2xl font-semibold">
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  )
}
