'use client'

import { useEffect, useState } from 'react'
import BottomNav from '@/components/BottomNav'
import { ShoppingCart, Heart, Star } from 'lucide-react'

interface Product {
  id: string
  name: string
  price: number
  category: string
  imageUrl: string
  stock: number
}

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [cart, setCart] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data.products || [])
        setLoading(false)
      })
      .catch(() => {
        setProducts([
          { id: "1", name: "Upcycled Denim Tote Bag", price: 89000, category: "Upcycled", imageUrl: "https://picsum.photos/id/1060/400/300", stock: 34 },
          { id: "2", name: "Bamboo Toothbrush Set (4pcs)", price: 45000, category: "Zero-Waste", imageUrl: "https://picsum.photos/id/1077/400/300", stock: 128 },
          { id: "3", name: "Recycled Ocean Plastic Notebook", price: 65000, category: "Eco-Friendly", imageUrl: "https://picsum.photos/id/106/400/300", stock: 67 },
          { id: "4", name: "Stainless Steel Reusable Straw Set", price: 35000, category: "Reusable", imageUrl: "https://picsum.photos/id/1080/400/300", stock: 92 },
        ])
        setLoading(false)
      })
  }, [])

  const addToCart = (product: Product) => {
    setCart([...cart, product])
    alert(`✅ Added ${product.name} to cart!`)
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      <div className="sticky top-0 z-40 bg-white px-4 py-4 border-b flex items-center justify-between">
        <h1 className="text-xl font-semibold">Eco Shop</h1>
        <div className="flex items-center gap-2 bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm">
          <ShoppingCart className="w-4 h-4" /> {cart.length}
        </div>
      </div>

      <div className="px-4 pt-6">
        <div className="grid grid-cols-2 gap-4">
          {products.map((product) => (
            <div key={product.id} className="eco-card overflow-hidden group">
              <div className="relative h-44 bg-gray-100">
                <img 
                  src={product.imageUrl} 
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
                <button className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow">
                  <Heart className="w-4 h-4 text-gray-400" />
                </button>
              </div>
              
              <div className="p-4">
                <div className="text-xs text-green-600 font-medium mb-1">{product.category}</div>
                <div className="font-semibold leading-tight line-clamp-2 h-10">{product.name}</div>
                
                <div className="flex items-center justify-between mt-4">
                  <div>
                    <div className="font-semibold text-lg">Rp.{product.price.toLocaleString('id-ID')}</div>
                    <div className="text-xs text-gray-500">{product.stock} left</div>
                  </div>
                  
                  <button 
                    onClick={() => addToCart(product)}
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-2xl text-sm font-medium active:scale-95 transition-all flex items-center gap-1"
                  >
                    <ShoppingCart className="w-4 h-4" /> Add
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {cart.length > 0 && (
          <div className="fixed bottom-24 left-4 right-4 bg-white shadow-xl rounded-3xl p-4 flex items-center justify-between z-50">
            <div>
              <div className="font-semibold">{cart.length} item(s) in cart</div>
              <div className="text-sm text-gray-500">Total: Rp.{cart.reduce((sum, p) => sum + p.price, 0).toLocaleString('id-ID')}</div>
            </div>
            <button 
              onClick={() => alert("🎉 Order placed! Thank you for shopping sustainably.")}
              className="bg-black text-white px-8 py-3 rounded-2xl font-semibold text-sm active:bg-gray-900"
            >
              Checkout
            </button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  )
}
