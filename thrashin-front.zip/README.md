# 🌍 ThrashIn — Smart Waste Management Platform

**Turn your waste into rewards.** Earn points, subscribe to waste pickup, and shop eco-friendly products.

## ✅ Features Implemented
- Real Authentication (NextAuth + Prisma)
- Subscription System (Create + Manage + Pause/Resume)
- Gamification & Monthly Leaderboard
- Interactive Map with Mapbox
- Eco Product Shop + Cart + Orders
- Profile & Order History

## Tech Stack
- Next.js 16 + TypeScript
- Tailwind CSS + Custom Eco Theme
- Prisma + PostgreSQL
- NextAuth.js
- Mapbox GL JS

## Quick Start

```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma db push
npm run seed
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

1. Push code to GitHub
2. Import on vercel.com
3. Add these env vars:
   - `DATABASE_URL` (your Postgres)
   - `NEXTAUTH_SECRET`
   - `NEXT_PUBLIC_MAPBOX_TOKEN` (optional)

---

**Built for a cleaner planet.** ♻️
