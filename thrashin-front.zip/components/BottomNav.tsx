'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Trophy, MapPin, ShoppingBag, User } from 'lucide-react'

export default function BottomNav() {
  const pathname = usePathname()

  const navItems = [
    { href: '/dashboard', icon: Home, label: 'Home' },
    { href: '/leaderboard', icon: Trophy, label: 'Rank' },
    { href: '/map', icon: MapPin, label: 'Map' },
    { href: '/products', icon: ShoppingBag, label: 'Shop' },
    { href: '/profile', icon: User, label: 'Profile' },
  ]

  return (
    <nav className="bottom-nav fixed bottom-0 left-0 right-0 z-50 border-t border-gray-200 px-4 py-2">
      <div className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = pathname === item.href
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-col items-center gap-1 px-4 py-1 rounded-xl transition-all ${
                isActive 
                  ? 'text-green-600' 
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'scale-110' : ''}`} />
              <span className="text-[10px] font-medium">{item.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
