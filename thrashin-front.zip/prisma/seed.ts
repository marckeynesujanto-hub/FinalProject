import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding ThrashIn database...')

  // Create demo user
  const user = await prisma.user.upsert({
    where: { email: 'pablo@thrashin.id' },
    update: {},
    create: {
      name: 'Pablo Ferdiansyah',
      email: 'pablo@thrashin.id',
      phone: '+6281234567890',
      points: 1240,
      level: 3,
      totalWasteKg: 124.5,
      avatarUrl: 'https://i.pravatar.cc/150?u=pablo',
    },
  })

  // Create Smart Bins
  await prisma.smartBin.createMany({
    data: [
      {
        name: "Binus University Drop Point",
        address: "Jl. K.H. Syahdan No.9, Palmerah, Jakarta",
        latitude: -6.2019,
        longitude: 106.7819,
        type: "MIXED",
        capacityKg: 150,
        currentFill: 87,
      },
      {
        name: "Kemang Eco Station",
        address: "Jl. Kemang Raya No. 45, Jakarta Selatan",
        latitude: -6.2605,
        longitude: 106.8134,
        type: "ORGANIC",
        capacityKg: 100,
        currentFill: 42,
      },
      {
        name: "SCBD Recycling Hub",
        address: "Jl. Jend. Sudirman No. 52, Jakarta",
        latitude: -6.2253,
        longitude: 106.8095,
        type: "INORGANIC",
        capacityKg: 200,
        currentFill: 156,
      },
    ],
  })

  // Create sample products
  await prisma.product.createMany({
    data: [
      {
        name: "Upcycled Denim Tote Bag",
        description: "Handcrafted from recycled jeans. Strong, stylish & zero waste.",
        price: 89000,
        category: "Upcycled",
        imageUrl: "https://picsum.photos/id/1060/400/300",
        stock: 34,
      },
      {
        name: "Bamboo Toothbrush Set (4pcs)",
        description: "100% biodegradable bamboo. Plastic-free oral care.",
        price: 45000,
        category: "Zero-Waste",
        imageUrl: "https://picsum.photos/id/1077/400/300",
        stock: 128,
      },
      {
        name: "Recycled Ocean Plastic Notebook",
        description: "Made from 100% recycled fishing nets. A5 size.",
        price: 65000,
        category: "Eco-Friendly",
        imageUrl: "https://picsum.photos/id/106/400/300",
        stock: 67,
      },
      {
        name: "Stainless Steel Reusable Straw Set",
        description: "With cleaning brush. Say no to single-use plastic.",
        price: 35000,
        category: "Reusable",
        imageUrl: "https://picsum.photos/id/1080/400/300",
        stock: 92,
      },
    ],
  })

  console.log('✅ Seed completed successfully!')
  console.log(`Demo user ID: ${user.id}`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
